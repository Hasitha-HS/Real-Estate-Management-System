package com.dea.PropertySphere.repository;

import com.dea.PropertySphere.Model.Campaign;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CampaignRepository extends JpaRepository<Campaign, Long>{
    
}
