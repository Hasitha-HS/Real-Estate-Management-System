package com.dea.PropertySphere;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertySphereApplicationTests {

	@Test
	void contextLoads() {
	}

}
